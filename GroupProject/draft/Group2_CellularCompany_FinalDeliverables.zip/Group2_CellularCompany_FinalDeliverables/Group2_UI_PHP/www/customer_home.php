<?php
$url = 'http://cdn.wonderfulengineering.com/wp-content/uploads/2014/01/Lenovo-wallpaper-6.jpg';
?>
<html>
<body>

								 <br><br><br><br><br><br><br><br><br><br><br><br><br>
								 <center>
                                 <ul>
					
                                 <li>
<style type="text/css">
body
{
background-image:url('<?php echo $url ?>');
}
.whitetext {
        color: white;
}
</style>

 <h2 class ="whitetext">Welcome to team Fantastic Mobile</h2>
								
<a href='manage_customer_info.php'><h2>Manage customer information</h2></a></li>
				                                  </ul>
								 </center>
</body>
</html>